% world constants
g = 9.8;

% tool parameters
F_y = 0*120 + 100 * g;

% z-slide rail parameters
E_st = 200.0e9;
sigma_y_st = 220e6;
tau_y_st = sigma_y_st * 0.5;
epsilon_max_st = 0.2/100;

l_r = 8.7 * 0.0254;
d_r = 0.75 * 0.0254;

I = pi() * d_r^4/64;
E = E_st;
sigma_y = sigma_y_st;
tau_y = tau_y_st;
epsilon_max = epsilon_max_st;

% carriage parameters
t_sk = 3/8; % thickness of carriage skirt plate in inches
m_c = 7;
% w_c = 4.5 * 0.0254;
% l_c = (3.75 - t_sk) * 0.0254;
% 
% x_m = (4.5/2 + 1.15) * 0.0254;
% x_c = 1.031 * 0.0254;
% z_t = (2.1875 - t_sk/2) * 0.0254;
% z_c = (l_r/2 - l_c/2);

w_c = 4.5 * 0.0254;
l_c = (3.75 - t_sk) * 0.0254;

x_m = w_c/2;
x_c = w_c/2;
z_t = l_c/2;
z_c = ((8.7 * 0.0254)/2 - l_c/2);

% carriage analysis
syms R_bt_var R_bh_var R_b_var
F_yc_eqn = -F_y - m_c * g + R_bt_var + R_bh_var + R_b_var;
M_xc_eqn = -R_bt_var * l_c/2 + R_bh_var * l_c/2 - F_y * (z_t - l_c/2); 
M_zc_eqn = -F_y * x_c - m_c * g * x_m + R_b_var * w_c;

sol = solve([F_yc_eqn == 0, M_xc_eqn == 0, M_zc_eqn == 0], [R_bt_var, R_bh_var, R_b_var]);
R_bt = vpa(sol.R_bt_var);
R_bh = vpa(sol.R_bh_var);
R_b = vpa(sol.R_b_var);

R_bt, R_bh, R_b

% carriage rail analysis
syms R_t_var R_h_var M_t_var M_h_var z
F_yr_eqn = R_t_var + R_h_var - R_bt - R_bh;
M_xr_eqn = -M_t_var + M_h_var - R_bt * z_c - R_bh * (z_c + l_c) + R_h_var * l_r;

V_bt_eqn = R_t_var;
M_bt_eqn = M_t_var + R_t_var * z;
theta_bt_eqn = 0 + 1/(E * I) * int(M_bt_eqn, [0 z]);
v_bt_eqn = 0 + int(theta_bt_eqn, [0 z]);
theta_bt = 0 + 1/(E * I) * int(M_bt_eqn, [0 z_c]);
v_bt = 0 + int(theta_bt_eqn, [0 z_c]);

V_bh_eqn = R_t_var - R_bt;
M_bh_eqn = M_t_var + R_t_var * z - R_bt * (z - z_c);
theta_bh_eqn = theta_bt + 1/(E * I) * int(M_bh_eqn, [z_c z]);
v_bh_eqn = v_bt + int(theta_bh_eqn, [z_c z]);
theta_bh = theta_bt + 1/(E * I) * int(M_bh_eqn, [z_c z_c + l_c]);
v_bh = v_bt + int(theta_bh_eqn, [z_c z_c + l_c]);

V_h_eqn = R_t_var - R_bt - R_bh;
M_h_eqn = M_t_var + + R_t_var * z - R_bt * (z - z_c) - R_bh * (z - z_c - l_c);
theta_h_eqn = theta_bh + 1/(E * I) * int(M_h_eqn, [z_c + l_c z]);
v_h_eqn = v_bh + int(theta_h_eqn, [z_c + l_c z]);
theta_h = theta_bh + 1/(E * I) * int(M_h_eqn, [z_c + l_c l_r]);
v_h = v_bh + int(theta_h_eqn, [z_c + l_c l_r]);

sol = solve([F_yr_eqn == 0, M_xr_eqn == 0, theta_h == 0, v_h == 0], [R_t_var, R_h_var, M_t_var, M_h_var]);
R_t = vpa(sol.R_t_var);
R_h = vpa(sol.R_h_var);
M_t = vpa(sol.M_t_var);
M_h = vpa(sol.M_h_var);

% R_t, R_h, M_t, M_h

V1_eqn = subs(V_bt_eqn, {R_t_var}, {R_t});
M1_eqn = subs(M_bt_eqn, {R_t_var, M_t_var}, {R_t, M_t});
theta1_eqn = subs(theta_bt_eqn, {R_t_var, M_t_var}, {R_t, M_t});
v1_eqn = subs(v_bt_eqn, {R_t_var, M_t_var}, {R_t, M_t});
% tau1_avg_eqn = (3 * V1_eqn)/(2 * d^2);
% sigma1_max_eqn = (M1_eqn * d/2)/I;
% 
V2_eqn = subs(V_bh_eqn, {R_t_var, M_t_var}, {R_t, M_t});
M2_eqn = subs(M_bh_eqn, {R_t_var, M_t_var}, {R_t, M_t});
theta2_eqn = subs(theta_bh_eqn, {R_t_var, M_t_var}, {R_t, M_t});
v2_eqn = subs(v_bh_eqn, {R_t_var, M_t_var}, {R_t, M_t});
% tau2_avg_eqn = (3 * V2_eqn)/(2 * d^2);
% sigma2_max_eqn = (M2_eqn * d/2)/I;
% 
V3_eqn = subs(V_h_eqn, {R_t_var, M_t_var}, {R_t, M_t});
M3_eqn = subs(M_h_eqn, {R_t_var, M_t_var}, {R_t, M_t});
theta3_eqn = subs(theta_h_eqn, {R_t_var, M_t_var}, {R_t, M_t});
v3_eqn = subs(v_h_eqn, {R_t_var, M_t_var}, {R_t, M_t});
% tau3_avg_eqn = (3 * V3_eqn)/(2 * d^2);
% sigma3_max_eqn = (M3_eqn * d/2)/I;
% 
num_points = 100;
z1 = linspace(0, z_c, num_points * (z_c/l_r));
z2 = linspace(z_c, z_c + l_c, num_points * (l_c/l_r));
z3 = linspace(z_c + l_c, l_r, num_points * (l_r - z_c - l_c)/l_r);
z_all = linspace(0, l_r, num_points);

close all;

figure;
subplot(2, 2, 1);
plot(z1, double(subs(V1_eqn, z, z1)), 'b', z2, double(subs(V2_eqn, z, z2)), 'g', z3, double(subs(V3_eqn, z, z3)), 'r');
grid on;
xlabel('z (m)');
ylabel('V(z) (N)');
title('Shear of Carriage Rail');

subplot(2, 2, 2);
plot(z1, double(subs(M1_eqn, z, z1)), 'b', z2, double(subs(M2_eqn, z, z2)), 'g', z3, double(subs(M3_eqn, z, z3)), 'r');
grid on;
xlabel('z (m)');
ylabel('M(z) (Nm)');
title('Moment of Carriage Rail');

subplot(2, 2, 3);
plot(z1, 180/pi() * double(subs(theta1_eqn, z, z1)), 'b', z2, 180/pi() * double(subs(theta2_eqn, z, z2)), 'g', z3, 180/pi() * double(subs(theta3_eqn, z, z3)), 'r');
grid on;
xlabel('z (m)');
ylabel('theta(z) (deg)');
title('Slope of Carriage Rail');

subplot(2, 2, 4 );
plot(z1, 1e6 * double(subs(v1_eqn, z, z1)), 'b', z2, 1e6 * double(subs(v2_eqn, z, z2)), 'g', z3, 1e6 * double(subs(v3_eqn, z, z3)), 'r');
grid on;
xlabel('z (m)');
ylabel('v(z) (µm)');
title('Deflection of Carriage Rail');

% 
% figure;
% subplot(2, 2, 1);
% plot(x1, double(subs(tau1_avg_eqn, x, x1)), 'b', x2, double(subs(tau2_avg_eqn, x, x2)), 'g', x3, double(subs(tau3_avg_eqn, x, x3)), 'r', ...
%     x_all, linspace(tau_y, tau_y, num_points), 'c', x_all, linspace(-tau_y, -tau_y, num_points), 'c');
% grid on;
% xlabel('x (m)');
% ylabel('tau_{avg}(x) (Pa)');
% title('Average Shear Stress of Torsion Bar');
% 
% subplot(2, 2, 2);
% plot(x1, double(subs(sigma1_max_eqn, x, x1)), 'b', x2, double(subs(sigma2_max_eqn, x, x2)), 'g', x3, double(subs(sigma3_max_eqn, x, x3)), 'r', ...
%     x_all, linspace(sigma_y, sigma_y, num_points), 'c', x_all, linspace(-sigma_y, -sigma_y, num_points), 'c');
% grid on;
% xlabel('x (m)');
% ylabel('sigma_{max}(x) (Pa)');
% title('Max Bending Stress of Torsion Bar');
% 
% subplot(2, 2, 3);
% plot(x1, double(subs(tau1_avg_eqn/G, x, x1)), 'b', x2, double(subs(tau2_avg_eqn/G, x, x2)), 'g', x3, double(subs(tau3_avg_eqn/G, x, x3)), 'r', ...
%     x_all, linspace(epsilon_max, epsilon_max, num_points), 'c', x_all, linspace(-epsilon_max, -epsilon_max, num_points), 'c');
% grid on;
% xlabel('x (m)');
% ylabel('gamma_{avg}(x)');
% title('Average Shear Strain of Torsion Bar');
% 
% subplot(2, 2, 4);
% plot(x1, double(subs(sigma1_max_eqn/E, x, x1)), 'b', x2, double(subs(sigma2_max_eqn/E, x, x2)), 'g', x3, double(subs(sigma3_max_eqn/E, x, x3)), 'r', ...
%     x_all, linspace(epsilon_max, epsilon_max, num_points), 'c', x_all, linspace(-epsilon_max, -epsilon_max, num_points), 'c');
% grid on;
% xlabel('x (m)');
% ylabel('epsilon_{max}(x)');
% title('Max Bending Strain of Torsion Bar');

%% RAIL FLEXURE MAXIMUM THICKNESS ALLOWED GIVEN A NORMAL FORCE AND A DEFLECTION
deflection = 125*10^-6 %m MAXIMUM EXPECTED DEFLECTION DURING REGULAR USE DUE TO FABRICATION ERRORS + STRAIGHTNESS TOLERANCE
force = 5*130 %N << NORMAL FORCE (FORCE TO BEND THE FLEXURE) = FRICTION FORCE ALLOTED / mu
L = 0.75 * 0.0254 %m
b = 1   * 0.0254 %m
E = 60*10^9 % Pa
h_cubed = ((force * L^3)/(3*E*(1/12)*b))/deflection
h = h_cubed ^(1/3) % in m
h_inch = h*39.3
