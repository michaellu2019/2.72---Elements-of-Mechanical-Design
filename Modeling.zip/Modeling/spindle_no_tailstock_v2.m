clear all
syms L1 L2 w L3  Fc Fb1 Fb2 Fb Es Is Ec Ic C1 C2 C3 C4

% boundary conditions
eq1 = 1/(2*Ec*Ic)*(Fc*L1^2 + C1/3) == C3/(6*Es*Is); % slope equivalence at material discontinuity (chuck)
eq2 = 1/(6*Ec*Ic)*(Fc*L1^3 + C1*L1 + C2) == 1/(6*Es*Is)*(C3*L1+C4); % position equivalence at material discontinuity (chuck)
eq3 = 0 == Fc*L1*L2^2/(2*Es*Is) + 1/(6*Es*Is)*(Fc*L2^3 + C3*(L1+L2) + C4);% front bearing position = 0
eq4 = 0 == Fc*L1*(L2+w)^2/(2*Es*Is) + 1/(6*Es*Is)*(Fc*(L2+w)^3 + Fb1*w^3 + C3*(L1+L2+w) + C4);% back bearing position = 0

eqns = [eq1, eq2, eq3, eq4];
vars = [C1, C2, C3, C4];
sols = solve(eqns, vars);

constant1 = sols.C1;
constant2 = sols.C2;
constant3 = sols.C3;
constant4 = sols.C4;

constants = [constant1, constant2, constant3, constant4];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% input variable
L1_r = 3*0.0254; % m (distance between chuck and cutting tool)
L2_r = 1.5*0.0254; % m (distance between front bearing and chuck)
w_r = 3*0.0254; % m (distance between spindle bearings)
L3_r = 2*0.0254; % m (distance from back bearing to belt)
Fc_r = 160; % N (cutting force)
Fb_r = 50; % N (belt force)
Es_r = 200e9; % Pa (E of spindle shaft)
D_spindle = 0.75*0.0254; % m (diameter of spindle shaft)
Is_r = pi/4*(D_spindle/2)^4; % m^4 (moment area of inertia of spindle shaft)
Ec_r = 70e9; % Pa (E of workpiece)
D_workpiece = 1*0.0254; % m (diameter of workpiece)
Ic_r =pi/4*(D_workpiece/2)^4; % m^4 (moment area of inertia of workpiece shaft)
%vars = [L1_r L2_r w L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r];


%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Bearing Forces as a function of spindle bearing spacing %%%%%%
% scan through bearing spacing values and acquire bearing loads
w_vals = linspace(1*0.0254, 5*0.0254, 60);
for i=1:length(w_vals)
    vars = [L1_r L2_r w_vals(i) L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r];
    result = deflection(0, vars, constants); % deflection evaluated at cutting tool position for max deflection
    deflection_vary_w(i) = result(1);
    front_bearing_force_vary_w(i) = result(2);
    back_bearing_force_vary_w(i) = result(3);
end

figure
plot(w_vals, deflection_vary_w)
title("deflection at tooltip as a function of spindle bearing spacing (no TS)")
xlabel("bearing spacing (m)");
ylabel("deflection at tooltip (m)")

figure
hold on
plot(w_vals, front_bearing_force_vary_w)
plot(w_vals, back_bearing_force_vary_w)
title("bearing loads vs spindle bearing spacing (no TS)")
xlabel("bearing spacing (m)")
ylabel("bearing loads (N)")
legend(["front bearing", "back bearing"])


%% 

% Calculate elastic curve for given parameters
w_r = 1.5*0.0254; % (m) define bearing spacing for elastic curve generation
vars = [L1_r L2_r w_r L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r];
x_vals = linspace(0, L1_r + L2_r + w_r + L3_r, 100);
for i=1:length(x_vals)
    result = deflection(x_vals(i), vars, constants);
    deflection_amount(i) = result(1);
    front_bearing_force(i) = result(2);
    back_bearing_force(i) = result(3);
end

% Plot elastic curve
figure
plot(x_vals, deflection_amount)
title("elastic curve of spindle (no TS)")
xlabel("Position (m)")
ylabel("Deflection (m)")

figure
hold on
plot(x_vals, front_bearing_force) % should be constant
plot(x_vals, back_bearing_force)
title("Bearing Forces (no TS)")
xlabel("Position (m)")
ylabel("bearing forces (N)")
legend(["front bearing", "back bearing"])

%% 
function result = deflection(x, vars, constants)
%result is an array containing bearing forces at tailstock, front, and back
%bearings and deflection with Fc_r applied at x: result = [defl, Fb1, Fb2]

% constants is a 1x4 array containing the 4 constants determined for this
% beam deflection subject to boundary coundations (found explicitly in
% Yasin's notebook) reflecting the lack of deflection of the bearings and
% tailstock as well as the continuity of the beam across different
% materials. 

syms L1 L2 w L3 Fc Fb Es Is Ec Ic
syms Fb1 Fb2 defl

C1 = constants(1);
C2 = constants(2);
C3 = constants(3);
C4 = constants(4);

% vars is a matrix containing all the variables relevant to the deflection
L1_r = vars(1);
L2_r = vars(2);
w_r = vars(3);
L3_r = vars(4);
Fc_r = vars(5);
Fb_r = vars(6);
Es_r = vars(7);
Is_r = vars(8);
Ec_r = vars(9);
Ic_r = vars(10);

C1 = subs(C1, [L1 L2 w L3 Fc Fb Es Is Ec Ic], [L1_r L2_r w_r L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);
C2 = subs(C2, [L1 L2 w L3 Fc Fb Es Is Ec Ic], [L1_r L2_r w_r L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);
C3 = subs(C3, [L1 L2 w L3 Fc Fb Es Is Ec Ic], [L1_r L2_r w_r L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);
C4 = subs(C4, [L1 L2 w L3 Fc Fb Es Is Ec Ic], [L1_r L2_r w_r L3_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);


if (x <= L1_r)
    v = 1/(6*Ec_r*Ic_r)*(Fc_r*x^3 + C1*x + C2);
elseif (x <= L1_r + L2_r)
    v = Fc_r*L1_r*(x-L1_r)^2/(2*Es_r*Is_r) + 1/(6*Es_r*Is_r)*(Fc_r*(x-L1_r)^3 + C3*x + C4);
elseif (x <= L1_r + L2_r + w_r)
    v  = Fc_r*L1_r*(x-L1_r)^2/(2*Es_r*Is_r) + 1/(6*Es_r*Is_r)*(Fc_r*(x-L1_r)^3 + Fb1*(x-L1_r-L2_r)^3 + C3*x + C4);
elseif (x <= L1_r + L2_r + w_r + L3_r)
    v = Fc_r*L1_r*(x-L1_r)^2/(2*Es_r*Is_r) + 1/(6*Es_r*Is_r)*(Fc_r*(x-L1_r)^3 + Fb1*(x-L1_r-L2_r)^3 + Fb2*(x-L1_r-L2_r-w_r)^3 + C3*x + C4);
end

% deflection equation in terms of Fb1, Fb2, Ft
eqn1 = defl == v;

% force balance
eqn2 = 0 == Fc_r + Fb1 + Fb2 + Fb_r; % on spindle shaft

% moment balance
eqn3 = 0 == -Fc_r*L1_r + Fb1*L2_r + Fb2*(L2_r+w_r) + Fb_r*(L2_r+w_r+L3_r); % on spindle shaft

eqns = [eqn1, eqn2, eqn3];
vars = [defl, Fb1, Fb2];
sols = solve(eqns, vars);

result = vpa([sols.defl, sols.Fb1, sols.Fb2]);

end




