% Spindle Thermal Modeling
clear all; close all; clc;
syms T_workpiece T_ho T_hi T_shaft Q_dis Q_spindle Q_w_to_air M_w m_w R_w R_conv_h h_w h_h R_total

T_air = 20; %C, environmental temperature
X_chips = 0.8; % fraction of heat that goes into chips from cutting
X_tool = 0.125; % fraction of heat that goes into too from cutting
u_st = 5e9; % J/m^3
MRR = pi*((0.25*0.0254)^2-(0.415/2*0.0254)^2)*6*0.0254/(8*60); % m^3/s
Q_cut = u_st*MRR*(1-X_chips-X_tool) + 45; % W, heat that remains in shaft to be transferred

L_h = 3*0.0254; %m, length of housing
r_ho = 1.5*0.0254; %m, outer housing radius
r_hi = 0.75/2*0.0254; %m, inner housing radius
L_w = 6*0.0254; %m, workpiece length
r_w = 0.25*0.0254; %m, workpiece radius
A_h = 2*pi*r_ho*L_h; %m^2, lateral surface area of housing
L_b = 0.655*0.0254; % m, bearing length
r_bo = 1.781/2*0.0254; % m, bearing outer radius
r_bi = 0.75/2*0.0254; %m, bearing inner radius
L_sh = 4.8*0.0254; %m, spindle shaft total length
r_sh = 0.75/2*0.0254; %m, spindle shaft radius
A_sh = pi * r_sh^2;
P_w = 2*pi*r_w; % m, perimeter of workpiece
A_w = pi*r_w^2; % m^2, cross sectional area of workpiece
A_w_lateral = 2 * pi * r_w * L_w;

k_st = 51.9; %W/m-K, thermal conductivity of steel
k_al = 167; %W/m-K, thermal conductivity of aluminum
h_w = 1.32*((T_workpiece - T_air)/(L_w * 1000))^(1/4); % convective heat transfer coeff for workpiece
h_h = 1.32*((T_ho - T_air)/(L_h * 1000))^(1/4); % % convective heat transfer coeff for housing

% model thermal resistivities
% m_w = sqrt(h_w*P_w/(k_st*A_w)); % thermal parameter for fin equations
% M_w = (T_workpiece - T_air)*sqrt(h_w*P_w*k_st*A_w); % thermal parameter for fin equations
R_w_conv = 1/(h_w * A_w_lateral);
R_w = L_w/(k_st * A_w); %1/sqrt(h_w*P_w*k_st*A_w)*(cosh(m_w*L_w)+h_w/m_w/k_st*sinh(m_w*L_w))/(sinh(m_w*L_w)+h_w/m_w/k_st*cosh(m_w*L_w)); % K/W, thermal resistance of workpiece (from fin equations)
% Q_w_to_air = M_w*(cosh(m_w*L_w)+h_w/m_w/k_st*sinh(m_w*L_w))/(sinh(m_w*L_w)+h_w/m_w/k_st*cosh(m_w*L_w)); % heat transfer rate from workpiece to environment (from fin equations)
R_sh = L_sh/(k_st * A_sh); %K/W thermal resistance of the spindle shaft
R_b = log(r_bo/r_bi)/(2*k_st*pi*L_b); % K/W thermal resistance radially of bearings
R_cond_h = log(r_ho/r_hi)/(2*k_al*pi*L_h); % K/W thermal resistance radially of housing
R_conv_h = 1/h_h/A_h; % K/W thermal convective resistance of housing
R_total = 1/(1/(R_w + R_sh + R_b/2 + R_cond_h + R_conv_h) + 1/R_w_conv);

% Thermal circuit equations
eqn1 = Q_w_to_air == (T_workpiece - T_air)/R_w_conv; %(T_shaft - T_air)/(R_sh + R_b/2 + R_cond_h +R_conv_h) == Q_spindle;
eqn2 = Q_spindle + Q_w_to_air == Q_cut;
eqn3 = T_ho == T_air + Q_spindle*R_conv_h;
eqn4 = T_hi == T_air + Q_spindle*(R_conv_h + R_cond_h);
eqn5 = T_shaft == T_air + Q_spindle*(R_conv_h + R_cond_h + 0.5*R_b + R_sh);
eqn6 = Q_cut == (T_workpiece - T_air)/R_total;

vars = [T_workpiece, T_ho, T_hi, T_shaft, Q_spindle, Q_w_to_air];
eqns = [eqn1, eqn2, eqn3, eqn4, eqn5, eqn6];

sols = solve(eqns, vars, 'Real', true, 'IgnoreAnalyticConstraints', true);
Q_spindle_actual = vpa(sols.Q_spindle)
Q_w_to_air_actual = vpa(sols.Q_w_to_air)
T_shaft_actual = vpa(sols.T_shaft) %C
T_workpiece_actual = vpa(sols.T_workpiece)
T_ho_actual = vpa(sols.T_ho)
T_hi = vpa(sols.T_hi)

h_w_actual = subs(h_w, {T_workpiece}, {T_workpiece_actual})
h_h_actual = subs(h_h, {T_ho}, {T_ho_actual})
