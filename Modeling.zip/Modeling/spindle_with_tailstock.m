clear all
syms L1 L2 L3 L4 L5 Fc Ft Fb1 Fb2 Fb Es Is Ec Ic C1 C2 C3 C4

Mc = Fc*L2 + Ft*(L1 + L2);

% boundary conditions
eq1 = 0 == 3*Mc*L3^2 + (Fc+Ft)*L3^3 + C1*(L1+L2+L3) + C2; % at front bearing
eq2 = 0 == 3*Mc*(L3+L4)^2 + (Fc+Ft)*(L3+L4)^3 + Fb1*L4^3 + C1*(L1+L2+L3+L4) + C2; % at back bearing
eq3 = 0 == C4; % at tailstock
eq4 = (C1*(L1+L2) + C2)/(6*Es*Is) == 1/(6*Ec*Ic)*(Ft*(L1+L2)^3 + Fc*L2^3 + C3*(L1+L2)+C4); % at material discontinuity (position equivalence)

eqns = [eq1, eq2, eq3, eq4];
vars = [C1, C2, C3, C4];
sols = solve(eqns, vars);

constant1 = sols.C1;
constant2 = sols.C2;
constant3 = sols.C3;
constant4 = sols.C4;

constants = [constant1, constant2, constant3, constant4];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% input variable
L1_r = 3*0.0254; % m (distance between cutting tool and tailstock)
L2_r = 3*0.0254; % m (distance between chuck and cutting tool)
L3_r = 1.5*0.0254; % m (distance between front bearing and chuck)
L4_r = 3*0.0254; % m (distance between spindle bearings
L5_r = 2*0.0254; % m (distance from back bearing to belt)
Fc_r = 160; % N (cutting force)
Fb_r = 50; % N (belt force)
Es_r = 200e9; % Pa (E of spindle shaft)
D_spindle = 0.75*0.0254; % m (diameter of spindle shaft)
Is_r = pi/4*(D_spindle/2)^4; % m^4 (moment area of inertia of spindle shaft)
Ec_r = 70e9; % Pa (E of workpiece)
D_workpiece = 1*0.0254; % m (diameter of workpiece)
Ic_r =pi/4*(D_workpiece/2)^4; % m^4 (moment area of inertia of workpiece shaft)
%vars = [L1_r L2_r L3_r L4_r L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r];


%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Bearing Forces as a function of spindle bearing spacing %%%%%%
% scan through bearing spacing values and acquire bearing loads
L4_vals = linspace(1*0.0254, 5*0.0254, 60);
for i=1:length(L4_vals)
    vars = [L1_r L2_r L3_r L4_vals(i) L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r];
    result = deflection(L1_r, vars, constants); % deflection evaluated at cutting tool position for max deflection
    deflection_vary_L4(i) = result(1);
    tailstock_bearing_force_vary_L4(i) = result(2);
    front_bearing_force_vary_L4(i) = result(3);
    back_bearing_force_vary_L4(i) = result(4);
end

figure
plot(L4_vals, deflection_vary_L4)
title("deflection at tooltip as a function of spindle bearing spacing")
xlabel("bearing spacing (m)");
ylabel("deflection at tooltip (m)")

figure
plot(L4_vals, tailstock_bearing_force_vary_L4)
hold on
plot(L4_vals, front_bearing_force_vary_L4)
plot(L4_vals, back_bearing_force_vary_L4)
title("bearing loads vs spindle bearing spacing")
xlabel("bearing spacing (m)")
ylabel("bearing loads (N)")
legend(["tailstock bearing", "front bearing", "back bearing"])


%% 

% Calculate elastic curve for given parameters
L4_r = 1.5*0.0254; % (m) define bearing spacing for elastic curve generation
vars = [L1_r L2_r L3_r L4_r L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r];
x_vals = linspace(0, L1_r + L2_r + L3_r + L4_r + L5_r, 100);
for i=1:length(x_vals)
    result = deflection(x_vals(i), vars, constants);
    deflection_amount(i) = result(1);
    tailstock_bearing_force(i) = result(2);
    front_bearing_force(i) = result(3);
    back_bearing_force(i) = result(4);
end

% Plot elastic curve
figure
plot(x_vals, deflection_amount)
title("elastic curve of spindle with tailstock")
xlabel("Position (m)")
ylabel("Deflection (m)")

figure
plot(x_vals, tailstock_bearing_force) %should be constant
hold on
plot(x_vals, front_bearing_force)
plot(x_vals, back_bearing_force)
title("Bearing Forces")
xlabel("Position (m)")
ylabel("bearing forces (N)")
legend(["tailstock", "front", "back"])

%% 
function result = deflection(x, vars, constants)
%result is an array containing bearing forces at tailstock, front, and back
%bearings and deflection with Fc_r applied at x: result = [defl, Ft, Fb1, Fb2]

% constants is a 1x4 array containing the 4 constants determined for this
% beam deflection subject to boundary coundations (found explicitly in
% Yasin's notebook) reflecting the lack of deflection of the bearings and
% tailstock as well as the continuity of the beam across different
% materials. 

syms L1 L2 L3 L4 L5 Fc Fb Es Is Ec Ic
syms Ft Fb1 Fb2 defl

C1 = constants(1);
C2 = constants(2);
C3 = constants(3);
C4 = constants(4);

% vars is a matrix containing all the variables relevant to the deflection
L1_r = vars(1);
L2_r = vars(2);
L3_r = vars(3);
L4_r = vars(4);
L5_r = vars(5);
Fc_r = vars(6);
Fb_r = vars(7);
Es_r = vars(8);
Is_r = vars(9);
Ec_r = vars(10);
Ic_r = vars(11);

C1 = subs(C1, [L1 L2 L3 L4 L5 Fc Fb Es Is Ec Ic], [L1_r L2_r L3_r L4_r L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);
C2 = subs(C2, [L1 L2 L3 L4 L5 Fc Fb Es Is Ec Ic], [L1_r L2_r L3_r L4_r L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);
C3 = subs(C3, [L1 L2 L3 L4 L5 Fc Fb Es Is Ec Ic], [L1_r L2_r L3_r L4_r L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);
C4 = subs(C4, [L1 L2 L3 L4 L5 Fc Fb Es Is Ec Ic], [L1_r L2_r L3_r L4_r L5_r Fc_r Fb_r Es_r Is_r Ec_r Ic_r]);

Mc = Fc_r*L2_r + Ft*(L1_r + L2_r);

if (x <= L1_r)
    v = 1/(6*Ec_r*Ic_r)*(Ft*x^3 + C3*x + C4);
elseif (x <= L1_r + L2_r)
    v = 1/(6*Ec_r*Ic_r)*(Ft*x^3 + Fc_r*(x-L1_r)^3 + C3*x + C4);
elseif (x <= L1_r + L2_r + L3_r)
    v  = Mc/(2*Es_r*Is_r)*(x-L1_r-L2_r)^2 + 1/(6*Es_r*Is_r)*((Fc_r+Ft)*(x-L1_r-L2_r)^3 + C1*x + C2);
elseif (x <= L1_r + L2_r + L3_r + L4_r)
    v = Mc/(2*Es_r*Is_r)*(x-L1_r-L2_r)^2 + 1/(6*Es_r*Is_r)*((Fc_r+Ft)*(x-L1_r-L2_r)^3 + Fb1*(x-L1_r-L2_r-L3_r)^3 + C1*x + C2);
elseif (x <= L1_r + L2_r + L3_r + L4_r +L5_r)
    v = Mc/(2*Es_r*Is_r)*(x-L1_r-L2_r)^2 + 1/(6*Es_r*Is_r)*((Fc_r+Ft)*(x-L1_r-L2_r)^3 + Fb1*(x-L1_r-L2_r-L3_r)^3 + Fb2*(x-L1_r-L2_r-L3_r-L4_r)^3 + C1*x + C2);
end

% deflection equation in terms of Fb1, Fb2, Ft
eqn1 = defl == v;

% force balance
eqn2 = 0 == Fc_r + Ft + Fb1 + Fb2 + Fb_r; % on spindle shaft

% moment balance
eqn3 = 0 == -Mc + Fb1*L3_r + Fb2*(L3_r+L4_r) + Fb_r*(L3_r+L4_r+L5_r); % on spindle shaft

% slope equivalence at material discontinuity (chuck)
eqn4 = 1/(2*Ec_r*Ic_r)*(Ft*(L1_r + L2_r)^2 + Fc_r*L2_r^2 + C3/3) == 1/(2*Es_r*Is_r)*C1/3; % at material discontinuity (slope equivalence)

eqns = [eqn1, eqn2, eqn3, eqn4];
vars = [defl, Ft, Fb1, Fb2];
sols = solve(eqns, vars);

result = vpa([sols.defl, sols.Ft, sols.Fb1, sols.Fb2]);

end




